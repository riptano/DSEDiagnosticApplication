The Health Check Console assemblies and exe need to be placed into ".\DSEDiagnosticApplication\DSEDiagnosticConsoleApplication\bin\Release".
The log4net.config file should not be replaced since it is setup for multiple user execution.
